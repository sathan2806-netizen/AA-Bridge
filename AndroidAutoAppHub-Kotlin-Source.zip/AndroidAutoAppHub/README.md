# Android Auto App Hub — Prototype 0.1.1

Android Kotlin prototype for managing notification integration from TradingView, Chrome, and TikTok on the phone.

## Implemented
- Select/deselect the three supported package IDs.
- Read notifications after the user explicitly enables Android Notification Access.
- Optional Vietnamese Text-to-Speech.
- Optional local notification history (up to 200 entries).
- Launch the selected source app from the phone.
- GitHub Actions workflow to build a debug APK.

## Important limitations
- This prototype is a phone-side notification hub. It does **not** implement an Android Auto car-screen interface or claim Android Auto approval.
- Notification content is only what each source app exposes in its Android notification. This is not an official TradingView data API and does not parse TradingView charts directly.
- TTS language availability depends on the phone's installed speech engine/voice.
- App package names can vary by app distribution/region; this prototype checks the common package IDs listed in the manifest.
- Android Auto permits only specific app categories and approved car-safe interfaces. Any car UI must be implemented and validated separately against current Android for Cars requirements.
- Package visibility is restricted to the three explicitly listed packages in `AndroidManifest.xml`, rather than requesting broad visibility of every installed app.

## Build APK using GitHub Actions
1. Create an empty GitHub repository.
2. Upload/push the contents of this project to the repository's `main` branch.
3. Open **Actions → Build Android APK → Run workflow** (or push a commit).
4. Download the `AndroidAutoAppHub-debug-apk` artifact from the completed run.

## Local build
Requires JDK 17, Android SDK Platform 35, Android build-tools, and network access on the first Gradle build:

```bash
./gradlew assembleDebug
```

The current ChatGPT execution environment does not have Android SDK / Gradle distribution cached and cannot resolve `services.gradle.org`, so an APK has not been compiled or device-tested here.
