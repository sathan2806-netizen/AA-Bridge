package com.example.apphub

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val appNames = linkedMapOf(
        "com.tradingview.tradingviewapp" to "TradingView — cảnh báo biểu đồ / BUY / SELL",
        "com.android.chrome" to "Chrome — thông báo trang web",
        "com.zhiliaoapp.musically" to "TikTok — thông báo ứng dụng"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) buildUi() }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
            setBackgroundColor(0xFFF4F7FB.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("ANDROID AUTO APP HUB", 23, true, 0xFF102A43.toInt()))
        root.addView(text("Bản thử nghiệm • Trung tâm thông báo", 14, false, 0xFF486581.toInt()))
        root.addView(gap(14))
        root.addView(text("1. Ứng dụng được chọn", 18, true, 0xFF102A43.toInt()))
        val selected = HubStore.selected(this)
        appNames.forEach { (pkg, label) ->
            val installed = isInstalled(pkg)
            val check = CheckBox(this).apply {
                text = if (installed) label else "$label (chưa cài đặt)"
                textSize = 15f
                isEnabled = installed
                isChecked = pkg in selected
                setPadding(0, dp(7), 0, dp(7))
                setOnCheckedChangeListener { _, checked ->
                    val updated = HubStore.selected(this@MainActivity)
                    if (checked) updated.add(pkg) else updated.remove(pkg)
                    HubStore.setSelected(this@MainActivity, updated)
                }
            }
            root.addView(check)
        }
        root.addView(gap(10))
        root.addView(text("2. Quyền và hành vi", 18, true, 0xFF102A43.toInt()))
        root.addView(actionButton(if (notificationAccessEnabled()) "✓ Quyền đọc thông báo đã bật" else "Bật quyền đọc thông báo") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(actionButton("Cài đặt thông báo Android") {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        })
        val speak = CheckBox(this).apply {
            text = "Đọc thông báo bằng giọng nói (tiếng Việt)"
            textSize = 15f
            isChecked = HubStore.speakEnabled(this@MainActivity)
            setPadding(0, dp(6), 0, dp(6))
            setOnCheckedChangeListener { _, checked -> HubStore.setSpeak(this@MainActivity, checked) }
        }
        root.addView(speak)
        val save = CheckBox(this).apply {
            text = "Lưu lịch sử thông báo trên điện thoại"
            textSize = 15f
            isChecked = HubStore.saveEnabled(this@MainActivity)
            setPadding(0, dp(6), 0, dp(6))
            setOnCheckedChangeListener { _, checked -> HubStore.setSave(this@MainActivity, checked) }
        }
        root.addView(save)
        root.addView(gap(10))
        root.addView(text("3. Lịch sử gần đây", 18, true, 0xFF102A43.toInt()))
        root.addView(actionButton("Làm mới lịch sử") { buildUi() })
        root.addView(actionButton("Xóa toàn bộ lịch sử") {
            AlertDialog.Builder(this).setTitle("Xóa lịch sử?").setMessage("Không thể hoàn tác thao tác này.")
                .setNegativeButton("Hủy", null).setPositiveButton("Xóa") { _, _ -> HubStore.clearHistory(this); buildUi() }.show()
        })
        val history = HubStore.history(this)
        if (history.isEmpty()) {
            root.addView(text("Chưa có thông báo được lưu. Hãy bật quyền đọc thông báo và chờ thông báo mới từ ứng dụng đã chọn.", 14, false, 0xFF627D98.toInt()))
        } else {
            val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault())
            history.take(30).forEach { item ->
                val time = fmt.format(Date(item.optLong("time")))
                val app = item.optString("app", "Ứng dụng")
                val title = item.optString("title", "")
                val body = item.optString("body", "")
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    setBackgroundColor(0xFFFFFFFF.toInt())
                }
                card.addView(text("$app • $time", 12, true, 0xFF486581.toInt()))
                if (title.isNotBlank()) card.addView(text(title, 15, true, 0xFF102A43.toInt()))
                if (body.isNotBlank()) card.addView(text(body, 14, false, 0xFF334E68.toInt()))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.setMargins(0, dp(4), 0, dp(6))
                root.addView(card, lp)
            }
        }
        root.addView(gap(12))
        root.addView(text("Android Auto: phiên bản này chưa tuyên bố hỗ trợ giao diện xe. Android Auto không cho phép hiển thị tùy ý mọi ứng dụng; cần xác minh danh mục được Google cho phép trước khi bổ sung giao diện trên xe.", 13, false, 0xFF9C2F2F.toInt()))
        root.addView(actionButton("Mở TradingView") { openApp("com.tradingview.tradingviewapp") })
        root.addView(actionButton("Mở Chrome") { openApp("com.android.chrome") })
        root.addView(actionButton("Mở TikTok") { openApp("com.zhiliaoapp.musically") })
    }

    private fun isInstalled(pkg: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) {
            packageManager.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getApplicationInfo(pkg, 0)
        }
        true
    } catch (_: Exception) { false }

    private fun notificationAccessEnabled(): Boolean {
        if (Build.VERSION.SDK_INT >= 27) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            return nm.isNotificationListenerAccessGranted(ComponentName(this, HubNotificationListener::class.java))
        }
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
        return enabled.contains(packageName)
    }

    private fun openApp(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else AlertDialog.Builder(this).setMessage("Ứng dụng chưa được cài đặt: $pkg").setPositiveButton("Đóng", null).show()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun text(value: String, size: Int, bold: Boolean, color: Int) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(3))
    }
    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(3), 0, dp(3)); layoutParams = lp
    }
    private fun gap(size: Int) = TextView(this).apply { height = dp(size) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
