package com.example.apphub

import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class HubNotificationListener : NotificationListenerService() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale("vi", "VN")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val selected = HubStore.selected(this)
        if (sbn.packageName !in selected || sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT))?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val appLabel = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        HubStore.addHistory(this, appLabel, title, text)
        if (HubStore.speakEnabled(this) && ttsReady) {
            val speech = listOf(appLabel, title, text).filter { it.isNotBlank() }.joinToString(". ")
            tts?.speak(speech, TextToSpeech.QUEUE_ADD, null, "hub-${sbn.key}-${sbn.postTime}")
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
