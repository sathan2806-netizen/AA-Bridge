package com.example.apphub

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object HubStore {
    private const val PREFS = "app_hub_prefs"
    private const val SELECTED = "selected_packages"
    private const val HISTORY = "notification_history"
    private const val SPEAK = "speak_notifications"
    private const val SAVE = "save_history"

    fun selected(context: Context): MutableSet<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(SELECTED, defaultPackages())?.toMutableSet() ?: defaultPackages()

    fun setSelected(context: Context, packages: Set<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putStringSet(SELECTED, packages.toSet()).apply()
    }

    private fun defaultPackages() = mutableSetOf(
        "com.tradingview.tradingviewapp", "com.android.chrome", "com.zhiliaoapp.musically"
    )

    fun speakEnabled(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(SPEAK, true)
    fun setSpeak(context: Context, enabled: Boolean) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(SPEAK, enabled).apply() }
    fun saveEnabled(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(SAVE, true)
    fun setSave(context: Context, enabled: Boolean) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(SAVE, enabled).apply() }

    @Synchronized fun addHistory(context: Context, app: String, title: String, body: String) {
        if (!saveEnabled(context)) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString(HISTORY, "[]")) } catch (_: Exception) { JSONArray() }
        val item = JSONObject().put("time", System.currentTimeMillis()).put("app", app).put("title", title).put("body", body)
        val next = JSONArray().put(item)
        for (i in 0 until minOf(old.length(), 199)) next.put(old.getJSONObject(i))
        prefs.edit().putString(HISTORY, next.toString()).apply()
    }

    fun history(context: Context): List<JSONObject> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(HISTORY, "[]")
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { i -> try { arr.getJSONObject(i) } catch (_: Exception) { null } }
    }

    fun clearHistory(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(HISTORY).apply() }
}
