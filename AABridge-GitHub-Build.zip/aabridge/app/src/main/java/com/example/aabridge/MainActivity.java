package com.example.aabridge;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * AA Bridge prototype: an on-phone catalog of launchable apps.
 * It does not add unsupported apps to Android Auto or mirror the phone screen.
 */
public class MainActivity extends Activity {
    private final List<AppEntry> allApps = new ArrayList<>();
    private final List<AppEntry> visibleApps = new ArrayList<>();
    private AppAdapter adapter;
    private EditText searchBox;

    private static class AppEntry {
        final String label;
        final String packageName;
        final Drawable icon;
        AppEntry(String label, String packageName, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.icon = icon;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        loadApps();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));
        root.setBackgroundColor(0xFFF5F7FA);

        TextView title = new TextView(this);
        title.setText("AA Bridge");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(0xFF14202B);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Danh sách ứng dụng có thể mở trên điện thoại");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF586575);
        subtitle.setPadding(0, dp(4), 0, dp(12));
        root.addView(subtitle);

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Tìm ứng dụng…");
        searchBox.setPadding(dp(12), 0, dp(12), 0);
        searchBox.setBackgroundColor(0xFFFFFFFF);
        root.addView(searchBox, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView note = new TextView(this);
        note.setText("Lưu ý: danh sách này là trình khởi chạy trên điện thoại; nó không tự đưa ứng dụng không tương thích lên Android Auto.");
        note.setTextSize(12);
        note.setTextColor(0xFF7A4B00);
        note.setPadding(dp(2), dp(10), dp(2), dp(8));
        root.addView(note);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setClipToPadding(false);
        list.setPadding(0, dp(4), 0, 0);
        adapter = new AppAdapter();
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        list.setOnItemClickListener((parent, view, position, id) -> launchApp(visibleApps.get(position)));
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterApps(s.toString()); }
            @Override public void afterTextChanged(Editable s) { }
        });
        setContentView(root);
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> resolved = pm.queryIntentActivities(query, 0);
        allApps.clear();
        for (android.content.pm.ResolveInfo ri : resolved) {
            if (ri.activityInfo == null) continue;
            String packageName = ri.activityInfo.packageName;
            // Hide this app from its own launcher list.
            if (getPackageName().equals(packageName)) continue;
            String label;
            Drawable icon;
            try {
                label = ri.loadLabel(pm).toString();
                icon = ri.loadIcon(pm);
            } catch (RuntimeException ex) {
                continue;
            }
            allApps.add(new AppEntry(label, packageName, icon));
        }
        Collections.sort(allApps, Comparator.comparing(a -> a.label.toLowerCase(Locale.ROOT)));
        filterApps(searchBox == null ? "" : searchBox.getText().toString());
    }

    private void filterApps(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        visibleApps.clear();
        for (AppEntry app : allApps) {
            if (app.label.toLowerCase(Locale.ROOT).contains(q) || app.packageName.toLowerCase(Locale.ROOT).contains(q)) {
                visibleApps.add(app);
            }
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void launchApp(AppEntry app) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(app.packageName);
            if (launch == null) {
                Toast.makeText(this, "Ứng dụng không cung cấp lối mở trực tiếp.", Toast.LENGTH_SHORT).show();
                return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (ActivityNotFoundException | SecurityException ex) {
            Toast.makeText(this, "Không thể mở ứng dụng này.", Toast.LENGTH_SHORT).show();
        }
    }

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleApps.size(); }
        @Override public Object getItem(int position) { return visibleApps.get(position); }
        @Override public long getItemId(int position) { return visibleApps.get(position).packageName.hashCode(); }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row;
            ImageView icon;
            LinearLayout labels;
            TextView name;
            TextView pkg;
            if (convertView instanceof LinearLayout) {
                row = (LinearLayout) convertView;
                icon = (ImageView) row.getChildAt(0);
                labels = (LinearLayout) row.getChildAt(1);
                name = (TextView) labels.getChildAt(0);
                pkg = (TextView) labels.getChildAt(1);
            } else {
                row = new LinearLayout(MainActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                row.setBackgroundColor(0xFFFFFFFF);
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
                rowParams.bottomMargin = dp(6);
                row.setLayoutParams(rowParams);

                icon = new ImageView(MainActivity.this);
                row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));
                labels = new LinearLayout(MainActivity.this);
                labels.setOrientation(LinearLayout.VERTICAL);
                labels.setPadding(dp(12), 0, 0, 0);
                row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));
                name = new TextView(MainActivity.this);
                name.setTextSize(16);
                name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                name.setTextColor(0xFF18212B);
                labels.addView(name);
                pkg = new TextView(MainActivity.this);
                pkg.setTextSize(11);
                pkg.setTextColor(0xFF657282);
                labels.addView(pkg);
                TextView open = new TextView(MainActivity.this);
                open.setText("MỞ  ›");
                open.setTextSize(12);
                open.setTextColor(0xFF1565C0);
                open.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                row.addView(open);
            }
            AppEntry app = visibleApps.get(position);
            icon.setImageDrawable(app.icon);
            name.setText(app.label);
            pkg.setText(app.packageName);
            return row;
        }
    }
}
