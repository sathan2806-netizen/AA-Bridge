# Build AA Bridge APK on GitHub Actions

This project cannot be compiled in the current ChatGPT container because Android SDK/Build Tools and Gradle are not installed and outbound DNS/network access is unavailable. This workflow builds the app on a hosted GitHub runner with Android SDK 35 and produces an installable **debug-signed** APK.

1. Create a new private repository on GitHub.
2. Upload the contents of this folder to the repository root (the `.github/workflows/build-apk.yml` file must be included).
3. Open the repository's **Actions** tab. Select **Build AA Bridge APK** and press **Run workflow** (or push to `main`).
4. When the run finishes successfully, open the run page and download the artifact named `AA-Bridge-debug-signed-APK`.
5. Extract `app-debug.apk` and install it on the phone. If Android asks, allow installation from that source.

The debug APK is signed automatically by Android Gradle Plugin with the standard debug key; it is suitable for testing, not Play Store release. This app currently catalogs and launches apps on the phone. It does not bypass Android Auto restrictions or make arbitrary apps appear on the car display.
