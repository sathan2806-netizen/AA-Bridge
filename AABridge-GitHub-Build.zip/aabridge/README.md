# AA Bridge — Android source prototype

## What this version does
- Lists launchable apps on the phone.
- Searches by app name or package name.
- Opens an app when its row is tapped.
- Uses Android's package visibility declaration to discover launchable apps.

## Important limitation
This is a phone-side app catalog/launcher prototype. It does **not** make arbitrary apps appear inside Android Auto. Android Auto only exposes approved app experiences through supported categories and APIs. A generic launcher that starts arbitrary phone activities from the car screen is not a supported universal bypass. This project intentionally does not use screen capture, accessibility abuse, hidden APIs, or projection bypasses.

## Build
1. Install Android Studio (a recent stable release) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync, then Build > Build APK(s).
4. Install the debug APK on an Android phone (Android 8.0+).

If publishing on Google Play, review the QUERY_ALL_PACKAGES policy. This prototype requests broad package visibility to show the app catalog; Play approval is not guaranteed.

## Next legitimate Android Auto step
Choose one supported category (for example audio/media, navigation, weather, or point of interest), then add the corresponding Android for Cars APIs and follow the category-specific quality and distribution requirements. This cannot expose every arbitrary app.
